﻿//Danillo Lima 
//1694006

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour
{
    public float pecaPorSegundo; 
    public Rigidbody pecaa, pecab, pecac;
    public List<Rigidbody> peca1;
    private int rand;
    int alturaJogaPeca = 5;
   
    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("CreatePeca", 0f, 4f);
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetMouseButtonDown(0)){
            Vector3 mouse = Input.mousePosition;
        }  
    }

    void CreatePeca()
    {
        int aleatorio = Random.Range(1,4);
        if (aleatorio == 1)
        {
            Rigidbody temp = Rigidbody.Instantiate(pecaa);
         //   temp.transform.SetParent(GameObject.Find("Plane").transform, false);
            temp.transform.position = new Vector3(12, alturaJogaPeca, 0);
        }
        else if (aleatorio == 2)
        {
            Rigidbody temp = Rigidbody.Instantiate(pecab);
         //   temp.transform.SetParent(GameObject.Find("Plane").transform, false);
            temp.transform.position = new Vector3(12, alturaJogaPeca, 0);
        }
        else
        {
            Rigidbody temp = Rigidbody.Instantiate(pecac);
          //  temp.transform.SetParent(GameObject.Find("Plane").transform, false);
            temp.transform.position = new Vector3(12, alturaJogaPeca, 0);
        }
        alturaJogaPeca += 3;
    }
}
