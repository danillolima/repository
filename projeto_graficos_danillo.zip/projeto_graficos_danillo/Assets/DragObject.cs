﻿//Danillo Lima 
//1694006

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragObject : MonoBehaviour
{
    private Vector3 mOffset;
    private float mZCoord;
    float angulo = 90.0f;
    float tempo = 0.01f;
    private bool taNoMouse = false;
    private Vector3 peca;
    private bool reverse = false;

    void OnMouseDown()
    {
        taNoMouse = true;
        mZCoord = Camera.main.WorldToScreenPoint(gameObject.transform.position).z;
      //if(Input.)
        // Store offset = gameobject world pos - mouse world pos
        mOffset = gameObject.transform.position - GetMouseAsWorldPoint();
    }

    private void OnMouseUp()
    {
        taNoMouse = false;
    }

    private Vector3 GetMouseAsWorldPoint()
    {
        // Pixel coordinates of mouse (x,y)
        Vector3 mousePoint = Input.mousePosition;
        // z coordinate of game object on screen
        mousePoint.z = mZCoord;
        // Convert it to world points
        return Camera.main.ScreenToWorldPoint(mousePoint);
    }

    void OnMouseDrag()
    {
        transform.position = GetMouseAsWorldPoint() + mOffset;
    }

    private void Update()
    {
        if(taNoMouse && Input.GetKeyDown(KeyCode.Space))
        {
           // transform.SetParent(GameObject.Find("Plane").transform, false);
            transform.Rotate(angulo, 0.0f, 0.0f, Space.World);
            //Quaternion target = Quaternion.Euler(angulo, 0, 0);
            //transform.rotation = Quaternion.Slerp(transform.rotation, target, Time.deltaTime * tempo);
            //transform.rotation = Quaternion.Euler(angulo, 0, 0);
            //Quaternion target = Quaternion.Euler(angulo, 0, 0);
            //taNoMouse = false;
        }
        if(taNoMouse && Input.GetKeyDown(KeyCode.B))
        {
            if (reverse)
            {
                transform.localScale -= new Vector3(0.5f, 0.5f, 0.5f);
                reverse = false;
            }
            else
            {
                transform.localScale += new Vector3(0.5f, 0.5f, 0.5f);
                reverse = true;
            }
        }
    }

}