﻿//Danillo Lima 
//1694006
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovimentacaoCubo : MonoBehaviour
{
    public float velTransl;
    public float velSalto;
    bool noPlano;
    
    void Start()
    {
        velTransl = 5f;
        velSalto = 100f;
        noPlano = true;
    }
    
    void Update()
    {
        Vector3 temp = new Vector3(0, 0, Input.GetAxis("Vertical"));
        temp *= velTransl * Time.deltaTime;
        if (Input.GetKey(KeyCode.Space) && noPlano)
        {
            temp.y = velSalto * Time.deltaTime;
            noPlano = false;
        }
        transform.Translate(temp);
        transform.Rotate(0, Input.GetAxis("Horizontal"),0);
    }

    private void OnCollisionEnter(Collision collision)
    {
        noPlano = true;
    }

    
}
